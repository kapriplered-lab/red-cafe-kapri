# KasirKu — Android POS Offline

Starter project Android native (Java) untuk aplikasi kasir offline.

## Fitur
- Katalog produk contoh dan tambah produk baru.
- Keranjang, tambah/kurangi kuantitas, hapus item, total otomatis.
- Pembayaran tunai, nominal cepat, status uang kurang/pas/kembalian.
- Pembayaran QRIS/transfer dengan konfirmasi manual.
- Rekap dan riwayat transaksi harian disimpan lokal.
- Pemilihan printer Bluetooth yang sudah dipasangkan dan perintah cetak ESC/POS dasar untuk printer Bluetooth Classic SPP 58 mm.
- Data disimpan di SharedPreferences lokal; aplikasi tidak memerlukan internet.

## Build APK
1. Buka folder `KasirKu` menggunakan Android Studio versi yang mendukung Android Gradle Plugin 8.6.1.
2. Pastikan Android SDK Platform 35 terpasang.
3. Tunggu Gradle Sync selesai.
4. Pilih **Build > Build APK(s)**.
5. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan penting
- Ini adalah proyek sumber, bukan APK yang sudah dikompilasi. Lingkungan pembuat berkas ini tidak menyediakan Android SDK/Gradle untuk mem-build APK di sini.
- Bluetooth menggunakan Bluetooth Classic Serial Port Profile (SPP) dan perintah ESC/POS dasar. Kompatibilitas tergantung model printer; beberapa printer BLE atau vendor-specific perlu SDK/protokol berbeda.
- Data tersimpan pada aplikasi/perangkat ini. Menghapus data aplikasi atau uninstall dapat menghapus data; lakukan backup sebelum penggunaan produksi.
- Pembayaran QRIS/transfer belum terhubung ke penyedia pembayaran; kasir harus memastikan pembayaran benar-benar diterima.
- Produk contoh bisa diubah atau ditambah dari menu Katalog.
